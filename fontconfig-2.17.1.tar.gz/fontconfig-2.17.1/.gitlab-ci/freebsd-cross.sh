#! /bin/sh

echo "** Cross build not supported."
exit 1
