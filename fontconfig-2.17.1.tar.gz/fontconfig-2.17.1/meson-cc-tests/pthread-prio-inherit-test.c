#include <pthread.h>

int
main (void)
{
    int i = PTHREAD_PRIO_INHERIT;

    return 0;
}
