#include <ft2build.h>
#include FT_CONFIG_OPTIONS_H
#ifndef PCF_CONFIG_OPTION_LONG_FAMILY_NAMES
#  error "No pcf long family names support"
#endif

int
main (void)
{
    return 0;
}
